/* ============================================================
   UTILIDAD GENERAL DE FORMATO DE MONEDA
   ============================================================ */
function fmtPesos(valor) {
  return valor.toLocaleString('es-CO', {
    style: 'currency',
    currency: 'COP',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
}

/* ------------------------------------------------------------
   PROBLEMA 1: Valor absoluto de un numero
   ------------------------------------------------------------ */
function valorAbsoluto(){
  var err = document.getElementById('err');
  var box = document.getElementById('result');
  var numero = parseFloat(document.getElementById('numero').value);
 
  if (isNaN(numero)) { err.classList.add('show'); box.classList.remove('show'); return; }
  err.classList.remove('show');
 
  var absoluto;
  if (numero < 0) {
    absoluto = -numero;
  } else {
    absoluto = numero;
  }
 
  document.getElementById('salida').textContent = 'El valor absoluto es: ' + absoluto;
  document.getElementById('paso').textContent =
    (numero < 0)
      ? '¿numero < 0? Verdadero → absoluto = ' + numero + ' × (-1) = ' + absoluto
      : '¿numero < 0? Falso → absoluto = ' + numero;
  box.classList.add('show');
}

/* ------------------------------------------------------------
   PROBLEMA 2: Descuento de supermercado segun numero al azar
   ------------------------------------------------------------ */
function descuentoSupermercado(){
  var err = document.getElementById('err');
  var box = document.getElementById('result');
  var total = parseFloat(document.getElementById('total').value);
 
  if (isNaN(total) || total < 0) { err.classList.add('show'); box.classList.remove('show'); return; }
  err.classList.remove('show');
 
  var azar = Math.floor(Math.random() * 101); // numero al azar entre 0 y 100
  var descuento, porc;
  if (azar < 74) {
    descuento = total * 0.15; porc = '15%'; // 15%
  } else {
    descuento = total * 0.20; porc = '20%'; // 20%
  }
  var pagar = total - descuento;
 
  document.getElementById('azar').textContent = azar;
  document.getElementById('porc').textContent = porc + (azar < 74 ? ' (azar < 74)' : ' (azar ≥ 74)');
  document.getElementById('descuento').textContent = fmtPesos(descuento);
  document.getElementById('pagar').textContent = fmtPesos(pagar);
  box.classList.add('show');
}

/* ------------------------------------------------------------
   PROBLEMA 3: Salario neto de vendedores
   ------------------------------------------------------------ */
var SMLV = 644336;    // SMLV 2015
var AUXILIO = 74000;  // Auxilio de transporte 2015
var vendedores = [];
 
function agregarVendedor(){
  var err = document.getElementById('err');
  var cedula = document.getElementById('cedula').value.trim();
  var nombre = document.getElementById('nombre').value.trim();
  var codigo = document.getElementById('codigo').value.trim();
  var basico = parseFloat(document.getElementById('basico').value);
  var ventas = parseFloat(document.getElementById('ventas').value);
  var prestamos = parseFloat(document.getElementById('prestamos').value);
 
  if (!cedula || !nombre || !codigo || isNaN(basico) || isNaN(ventas) || isNaN(prestamos)) {
    err.textContent = 'Complete todos los campos con valores validos.'; err.classList.add('show'); return;
  }
  err.classList.remove('show'); err.textContent = '';
 
  // Auxilio si el basico esta entre 1 y 3 SMLV
  var auxilio;
  if (basico >= SMLV && basico <= 3 * SMLV) { auxilio = AUXILIO; } else { auxilio = 0; }
 
  var comision = ventas * 0.02;                      // comision del 2%
  var totalDevengado = basico + auxilio + comision;
  var deduccionObligatoria = basico * 0.05;          // 5% obligatorio sobre el basico
  var totalDeducciones = deduccionObligatoria + prestamos;
  var neto = totalDevengado - totalDeducciones;
 
  vendedores.push({ cedula:cedula, nombre:nombre, codigo:codigo,
                    basico:basico, auxilio:auxilio, comision:comision,
                    prestamos:prestamos, neto:neto });
  renderVendedores();
 
  ['cedula','nombre','codigo','basico','ventas','prestamos'].forEach(function(id){
    document.getElementById(id).value = '';
  });
  document.getElementById('cedula').focus();
}
 
function renderVendedores(){
  var tbody = document.getElementById('tbody');
  tbody.innerHTML = '';
  vendedores.forEach(function(v){
    var tr = document.createElement('tr');
    tr.innerHTML =
      '<td class="left">' + v.cedula + '</td>' +
      '<td class="left">' + v.nombre + '</td>' +
      '<td class="left">' + v.codigo + '</td>' +
      '<td>' + fmtPesos(v.basico) + '</td>' +
      '<td>' + fmtPesos(v.auxilio) + '</td>' +
      '<td>' + fmtPesos(v.comision) + '</td>' +
      '<td>' + fmtPesos(v.prestamos) + '</td>' +
      '<td class="neto">' + fmtPesos(v.neto) + '</td>';
    tbody.appendChild(tr);
  });
  document.getElementById('tabla').classList.toggle('show', vendedores.length > 0);
  document.getElementById('counter').textContent =
    vendedores.length ? ('Vendedores registrados: ' + vendedores.length) : '';
}
 
function limpiarVendedores(){ vendedores = []; renderVendedores(); }

/* ------------------------------------------------------------
   PROBLEMA 4: Matriz M(50,5) de alumnos
   Columnas: codigo, nota1, nota2, nota3, nota_final (promedio)
   ------------------------------------------------------------ */
var M = []; // matriz (arreglo de arreglos)
 
function agregarAlumno(){
  var err = document.getElementById('err');
  var codigo = document.getElementById('codigo').value.trim();
  var n1 = parseFloat(document.getElementById('n1').value);
  var n2 = parseFloat(document.getElementById('n2').value);
  var n3 = parseFloat(document.getElementById('n3').value);
 
  if (!codigo) { err.textContent = 'Ingrese el codigo del alumno.'; err.classList.add('show'); return; }
  // Control de rango 1.0 a 5.0
  if (isNaN(n1) || n1 < 1.0 || n1 > 5.0 ||
      isNaN(n2) || n2 < 1.0 || n2 > 5.0 ||
      isNaN(n3) || n3 < 1.0 || n3 > 5.0) {
    err.textContent = 'Nota invalida: las tres notas deben estar entre 1.0 y 5.0.';
    err.classList.add('show'); return;
  }
  err.classList.remove('show'); err.textContent = '';
 
  var final = (n1 + n2 + n3) / 3;
  M.push([codigo, n1, n2, n3, final]);
  renderAlumnos();
 
  ['codigo','n1','n2','n3'].forEach(function(id){ document.getElementById(id).value = ''; });
  document.getElementById('codigo').focus();
}
 
function clasificarAlumno(final){
  if (final === 5.0) return { t:'Aprobado / Maxima', c:'max' };
  if (final >= 3.0 && final <= 5.0) return { t:'Aprobado', c:'apro' };
  if (final >= 2.0 && final <= 2.9) return { t:'Recuperacion', c:'recu' };
  return { t:'Reprobado', c:'rep' };
}
 
function renderAlumnos(){
  var tbody = document.getElementById('tbody');
  tbody.innerHTML = '';
  var aprobados = 0, recuperacion = 0, maxima = 0;
 
  M.forEach(function(f){
    var final = f[4];
    if (final >= 3.0 && final <= 5.0) { aprobados++; }
    else if (final >= 2.0 && final <= 2.9) { recuperacion++; }
    if (final === 5.0) { maxima++; }
 
    var cl = clasificarAlumno(final);
    var tr = document.createElement('tr');
    tr.innerHTML =
      '<td>' + f[0] + '</td>' +
      '<td>' + f[1].toFixed(1) + '</td>' +
      '<td>' + f[2].toFixed(1) + '</td>' +
      '<td>' + f[3].toFixed(1) + '</td>' +
      '<td><b>' + final.toFixed(2) + '</b></td>' +
      '<td><span class="tag ' + cl.c + '">' + cl.t + '</span></td>';
    tbody.appendChild(tr);
  });
 
  document.getElementById('cApro').textContent = aprobados;
  document.getElementById('cRecu').textContent = recuperacion;
  document.getElementById('cMax').textContent = maxima;
  document.getElementById('cards').style.display = M.length ? 'grid' : 'none';
  document.getElementById('tabla').classList.toggle('show', M.length > 0);
}
 
function limpiarAlumnos(){ M = []; renderAlumnos(); }

/* ============================================================
   PROBLEMA 5: TABLA DE AMORTIZACIÓN
   ============================================================ */
var DEUDA_MINIMA   = 2000000;
var INTERES_MINIMO = 1;
var INTERES_MAXIMO = 5;
var PLAZO_MINIMO   = 1;
var PLAZO_MAXIMO   = 360;
 
var URL_IDIOMA_ES = 'https://cdn.datatables.net/plug-ins/2.1.8/i18n/es-ES.json';
 
var IDIOMA_ES_RESPALDO = {
  decimal: ',',
  thousands: '.',
  emptyTable: 'No hay datos disponibles en la tabla',
  info: 'Mostrando _START_ a _END_ de _TOTAL_ cuotas',
  infoEmpty: 'Mostrando 0 a 0 de 0 cuotas',
  infoFiltered: '(filtrado de _MAX_ cuotas en total)',
  lengthMenu: 'Mostrar _MENU_ cuotas',
  loadingRecords: 'Cargando...',
  processing: 'Procesando...',
  search: 'Buscar:',
  zeroRecords: 'No se encontraron resultados',
  paginate: { first: 'Primero', last: 'Último', next: 'Siguiente', previous: 'Anterior' },
  aria: { orderable: 'Ordenar por esta columna', orderableReverse: 'Invertir el orden de esta columna' }
};
 
var tablaDT       = null;
var idiomaTabla   = IDIOMA_ES_RESPALDO;
var ultimoCalculo = null;
 
function renderizarPesos(dato, tipo) {
  if (tipo === 'display' || tipo === 'filter') {
    return fmtPesos(dato);
  }
  return dato;
}
 
function leerDatosFormulario() {
  return {
    deuda:   parseFloat($('#deuda').val()),
    interes: parseFloat($('#interes').val()),
    plazo:   Number($('#plazo').val())
  };
}
 
function validarDatos(datos) {
  var errores = [];
  if (isNaN(datos.deuda)) {
    errores.push({ campo: 'deuda', mensaje: 'Escriba el valor de la deuda (solo números).' });
  } else if (datos.deuda <= 0) {
    errores.push({ campo: 'deuda', mensaje: 'La deuda debe ser un valor positivo.' });
  } else if (datos.deuda <= DEUDA_MINIMA) {
    errores.push({ campo: 'deuda', mensaje: 'La deuda debe ser mayor a ' + fmtPesos(DEUDA_MINIMA) + '.' });
  }
 
  if (isNaN(datos.interes)) {
    errores.push({ campo: 'interes', mensaje: 'Escriba el interés mensual (solo números).' });
  } else if (datos.interes < INTERES_MINIMO) {
    errores.push({ campo: 'interes', mensaje: 'El interés debe ser positivo y mínimo ' + INTERES_MINIMO + '%.' });
  } else if (datos.interes > INTERES_MAXIMO) {
    errores.push({ campo: 'interes', mensaje: 'Supera la tasa de usura: máximo ' + INTERES_MAXIMO + '% mensual.' });
  }
 
  if ($('#plazo').val() === '' || isNaN(datos.plazo)) {
    errores.push({ campo: 'plazo', mensaje: 'Escriba el plazo en meses.' });
  } else if (!Number.isInteger(datos.plazo)) {
    errores.push({ campo: 'plazo', mensaje: 'El plazo debe ser un número entero de meses (sin decimales).' });
  } else if (datos.plazo < PLAZO_MINIMO || datos.plazo > PLAZO_MAXIMO) {
    errores.push({ campo: 'plazo', mensaje: 'El plazo debe estar entre ' + PLAZO_MINIMO + ' y ' + PLAZO_MAXIMO + ' meses.' });
  }
  return errores;
}
 
function limpiarErrores() {
  $('.campo-error').text('');
  $('#formAmortizacion input').removeClass('invalido');
  $('#err').removeClass('show').text('');
}
 
function mostrarErrores(errores) {
  limpiarErrores();
  $.each(errores, function (indice, error) {
    $('#error-' + error.campo).text(error.mensaje);
    $('#' + error.campo).addClass('invalido');
  });
  $('#err').addClass('show').text('Corrija los ' + errores.length + ' dato(s) marcados en rojo.');
  $('#' + errores[0].campo).trigger('focus');
}
 
function calcularCuotaFija(deuda, tasaMensual, plazo) {
  var i = tasaMensual / 100;
  return (deuda * i) / (1 - Math.pow(1 + i, -plazo));
}
 
function generarTablaAmortizacion(deuda, tasaMensual, plazo) {
  var i = tasaMensual / 100;
  var cuota = calcularCuotaFija(deuda, tasaMensual, plazo);
  var saldo = deuda;
  var filas = [];
  var totalIntereses = 0;
  var totalPagado = 0;
 
  for (var mes = 1; mes <= plazo; mes++) {
    var interesMes = saldo * i;
    var abonoCapital = cuota - interesMes;
    var cuotaMes = cuota;
 
    if (mes === plazo) {
      abonoCapital = saldo;
      cuotaMes = abonoCapital + interesMes;
    }
 
    saldo = saldo - abonoCapital;
    if (Math.abs(saldo) < 0.005) {
      saldo = 0;
    }
 
    totalIntereses += interesMes;
    totalPagado += cuotaMes;
    filas.push([mes, cuotaMes, interesMes, abonoCapital, saldo]);
  }
 
  return {
    deuda: deuda,
    interes: tasaMensual,
    plazo: plazo,
    cuota: cuota,
    filas: filas,
    totalIntereses: totalIntereses,
    totalPagado: totalPagado
  };
}
 
function cargarIdiomaConAjax() {
  $.ajax({
    url: URL_IDIOMA_ES,
    method: 'GET',
    dataType: 'json',
    timeout: 5000
  })
    .done(function (respuesta) {
      idiomaTabla = $.extend(true, {}, IDIOMA_ES_RESPALDO, respuesta);
      $('#estadoAjax').addClass('ok').text('✔ Idioma español de la tabla cargado por AJAX desde el CDN de DataTables.');
    })
    .fail(function () {
      idiomaTabla = IDIOMA_ES_RESPALDO;
      $('#estadoAjax').addClass('alerta').text('⚠ No se pudo cargar el idioma por AJAX; se usa la traducción local de respaldo.');
    });
}
 
function mostrarEnDataTable(filas) {
  if (tablaDT === null) {
    tablaDT = $('#tablaAmortizacion').DataTable({
      data: filas,
      language: idiomaTabla,
      pageLength: 12,
      lengthMenu: [12, 24, 36, 60, 120],
      order: [[0, 'asc']],
      columns: [
        { title: 'N° cuota', className: 'dt-center' },
        { title: 'Cuota',           render: renderizarPesos, className: 'dt-right' },
        { title: 'Interés',         render: renderizarPesos, className: 'dt-right' },
        { title: 'Abono a capital', render: renderizarPesos, className: 'dt-right' },
        { title: 'Saldo',           render: renderizarPesos, className: 'dt-right' }
      ]
    });
  } else {
    tablaDT.clear().rows.add(filas).draw();
  }
}
 
function calcularAmortizacion() {
  var datos = leerDatosFormulario();
  var errores = validarDatos(datos);
 
  if (errores.length > 0) {
    mostrarErrores(errores);
    $('#seccionResultados').addClass('oculto');
    return;
  }
  limpiarErrores();
 
  ultimoCalculo = generarTablaAmortizacion(datos.deuda, datos.interes, datos.plazo);
 
  $('#resCuota').text(fmtPesos(ultimoCalculo.cuota));
  $('#resIntereses').text(fmtPesos(ultimoCalculo.totalIntereses));
  $('#resTotal').text(fmtPesos(ultimoCalculo.totalPagado));
 
  $('#seccionResultados').removeClass('oculto');
  mostrarEnDataTable(ultimoCalculo.filas);
}
 
function limpiarFormulario() {
  $('#formAmortizacion')[0].reset();
  limpiarErrores();
  $('#seccionResultados').addClass('oculto');
  if (tablaDT !== null) {
    tablaDT.clear().draw();
  }
  ultimoCalculo = null;
  $('#deuda').trigger('focus');
}
 
function construirHtmlImpresion(calculo) {
  var fecha = new Date().toLocaleString('es-CO');
  var html = '';
 
  html += '<div class="impresion">';
  html += '<h3>Tabla de amortización — Cuota fija (sistema francés)</h3>';
  html += '<p class="fecha">Generada el ' + fecha + '</p>';
 
  html += '<div class="resumen">';
  html += '<div><b>Valor de la deuda:</b> ' + fmtPesos(calculo.deuda) + '</div>';
  html += '<div><b>Interés mensual:</b> ' + calculo.interes + ' %</div>';
  html += '<div><b>Plazo:</b> ' + calculo.plazo + ' meses</div>';
  html += '<div><b>Cuota mensual:</b> ' + fmtPesos(calculo.cuota) + '</div>';
  html += '<div><b>Total intereses:</b> ' + fmtPesos(calculo.totalIntereses) + '</div>';
  html += '<div><b>Total pagado:</b> ' + fmtPesos(calculo.totalPagado) + '</div>';
  html += '</div>';
 
  html += '<table><thead><tr>';
  html += '<th>N° cuota</th><th>Cuota</th><th>Interés</th><th>Abono a capital</th><th>Saldo</th>';
  html += '</tr></thead><tbody>';
 
  $.each(calculo.filas, function (indice, fila) {
    html += '<tr>';
    html += '<td>' + fila[0] + '</td>';
    html += '<td>' + fmtPesos(fila[1]) + '</td>';
    html += '<td>' + fmtPesos(fila[2]) + '</td>';
    html += '<td>' + fmtPesos(fila[3]) + '</td>';
    html += '<td>' + fmtPesos(fila[4]) + '</td>';
    html += '</tr>';
  });
 
  html += '</tbody><tfoot><tr>';
  html += '<td>Totales</td>';
  html += '<td>' + fmtPesos(calculo.totalPagado) + '</td>';
  html += '<td>' + fmtPesos(calculo.totalIntereses) + '</td>';
  html += '<td>' + fmtPesos(calculo.deuda) + '</td>';
  html += '<td>—</td>';
  html += '</tr></tfoot></table>';
  html += '</div>';
 
  html += '</div>';
  return html;
}
 
function abrirModalImpresion() {
  if (ultimoCalculo === null) { return; }
  $('#zonaImpresion').html(construirHtmlImpresion(ultimoCalculo));
  $('#modalImprimir').addClass('abierto').attr('aria-hidden', 'false');
  $('body').addClass('modal-abierto');
  $('#btnImprimir').trigger('focus');
}
 
function cerrarModalImpresion() {
  $('#modalImprimir').removeClass('abierto').attr('aria-hidden', 'true');
  $('body').removeClass('modal-abierto');
  $('#btnAbrirModal').trigger('focus');
}
 
function imprimirTabla() {
  window.print();
}
 
if (typeof window !== 'undefined' && window.jQuery) {
  $(function () {
    if (!document.getElementById('formAmortizacion')) {
      return;
    }
 
    cargarIdiomaConAjax();
 
    $('#formAmortizacion').on('submit', function (evento) {
      evento.preventDefault();
      calcularAmortizacion();
    });
 
    $('#btnLimpiar').on('click', limpiarFormulario);
 
    $('#formAmortizacion input').on('input', function () {
      $(this).removeClass('invalido');
      $('#error-' + this.id).text('');
    });
 
    $('#btnAbrirModal').on('click', abrirModalImpresion);
    $('#btnImprimir').on('click', imprimirTabla);
    $('#btnCerrarModal, #btnCerrarX').on('click', cerrarModalImpresion);
 
    $('#modalImprimir').on('click', function (evento) {
      if (evento.target === this) {
        cerrarModalImpresion();
      }
    });
 
    $(document).on('keydown', function (evento) {
      if (evento.key === 'Escape' && $('#modalImprimir').hasClass('abierto')) {
        cerrarModalImpresion();
      }
    });
  });
}